- Projection EPSG:26914 

- Blocks do not merge neatly within Precint 1's boundaries
- " within Precinct 2's boundaries
- " within Precinct 3's boundaries
- " within Precinct 4's boundaries
- " within Precinct 5's boundaries
